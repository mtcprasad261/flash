package pom.booking.util;

public class constants {
	//Application details
	public static final String APP_URL="https://www.makemytrip.com/";
	public static final String BROWSER_TYPE="chrome";
	public static final String USERNAME="swamykumartesting@gmail.com";
	public static final String PASSWORD="Pass@word1";
	//paths to drivers
	public static final String FIREFOX_DRIVER="drivers//geckodriver.exe";
	public static final String CHROME_DRIVER="drivers//chromedriver.exe";
}
